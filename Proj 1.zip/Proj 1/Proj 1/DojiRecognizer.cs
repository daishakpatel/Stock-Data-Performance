﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj_1
{
    internal class DojiRecognizer : Recognizer
    {
        public DojiRecognizer() : base("Doji", 1)
        {

        }

        /* List<int> recognizedDojiIndexes(List<smartCandleStick> scs)
         {
             List<int> dojiIndexes = new List<int>();
             for (int i = 0; i < scs.Count; i++)
             {
                 if (scs[i].isDoji)
                 {
                     dojiIndexes.Add(i);
                 }
             }
             return dojiIndexes;
         }*/
        /* protected override Boolean recognizePattern(smartCandleStick scs)
         {
             return scs.isDoji;
         }*/

        protected override Boolean recognizePattern(List<smartCandleStick> scsl)
        {
            return scsl[0].isDoji;
        }
    }
}
