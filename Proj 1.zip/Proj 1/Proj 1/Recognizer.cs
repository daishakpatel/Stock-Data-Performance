﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj_1
{
    abstract internal class Recognizer
    {
        public int patternSize;
        public string patternName;
        protected Recognizer(string PatternName, int PatternSize)
        {
            this.patternName = PatternName;
            this.patternSize = PatternSize;
        }
        protected abstract Boolean recognizePattern(List<smartCandleStick> scsl);

        public List<int> recognizePatterns(List<smartCandleStick> scsl)
        {
            List<int> recognizedIndexes = new List<int>();
            for (int i = patternSize - 1; i < scsl.Count; i++)
            {
                List<smartCandleStick> subscsl = scsl.GetRange(i - patternSize + 1, patternSize);

                if (recognizePattern(subscsl))
                {
                    recognizedIndexes.Add(i);
                }
            }
            return recognizedIndexes;
        }

        /*   public List<smartCandleStick> getRecognizedCandleSticks(List<smartCandleStick> scsl)
           {
               List<smartCandleStick> recognizedCandleSticks = new List<smartCandleStick>();
               List<int> recognizedIndexes = recognizedDojiIndexes(scsl);
               foreach (int i in recognizedIndexes)
               {
                   recognizedCandleSticks.Add(scsl[i]);
               }
               return recognizedCandleSticks;
           }


        Boolean peakrecognizePattern(lscs)
            {
            smartCandleStick s0 = lscs[0];
            smartCandleStick s1 = lscs[1];
            smartCandleStick s2 = lscs[2];

            return (s1.high > s0.high && s1.high > s2.high);
            }   
            
        Bullish
        Bearish
        Neutral
        Marubozu
        Doji
        DragonFlyDoji
        GravestoneDoji
        Hammer
        InvertedHammer*/

    }

}