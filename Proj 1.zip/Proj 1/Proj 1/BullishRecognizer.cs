﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj_1
{
    internal class BullishRecognizer : Recognizer
    {
        public BullishRecognizer() : base("Bullish", 1)
        {

        }

        protected override Boolean recognizePattern(List<smartCandleStick> scsl)
        {
            return scsl[0].isBullish;
        }
    }
}
