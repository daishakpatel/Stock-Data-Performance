﻿namespace Proj_1
{
    partial class FormEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainLabel = new System.Windows.Forms.Label();
            this.button_Load = new System.Windows.Forms.Button();
            this.LoaddateTimePicker_endDate = new System.Windows.Forms.DateTimePicker();
            this.LoaddateTimePicker_startDate = new System.Windows.Forms.DateTimePicker();
            this.StartDateLabel = new System.Windows.Forms.Label();
            this.EndDateLabel = new System.Windows.Forms.Label();
            this.LoadButtonOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // MainLabel
            // 
            this.MainLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.MainLabel.AutoSize = true;
            this.MainLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainLabel.Location = new System.Drawing.Point(264, 26);
            this.MainLabel.Name = "MainLabel";
            this.MainLabel.Size = new System.Drawing.Size(246, 38);
            this.MainLabel.TabIndex = 8;
            this.MainLabel.Text = "Stock Analysis";
            this.MainLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button_Load
            // 
            this.button_Load.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Load.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Load.Location = new System.Drawing.Point(331, 166);
            this.button_Load.Name = "button_Load";
            this.button_Load.Size = new System.Drawing.Size(111, 46);
            this.button_Load.TabIndex = 11;
            this.button_Load.Text = "Load";
            this.button_Load.UseVisualStyleBackColor = true;
            this.button_Load.Click += new System.EventHandler(this.button_Load_Click);
            // 
            // LoaddateTimePicker_endDate
            // 
            this.LoaddateTimePicker_endDate.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LoaddateTimePicker_endDate.Location = new System.Drawing.Point(473, 133);
            this.LoaddateTimePicker_endDate.Name = "LoaddateTimePicker_endDate";
            this.LoaddateTimePicker_endDate.Size = new System.Drawing.Size(254, 22);
            this.LoaddateTimePicker_endDate.TabIndex = 12;
            this.LoaddateTimePicker_endDate.Value = new System.DateTime(2023, 7, 15, 0, 0, 0, 0);
            // 
            // LoaddateTimePicker_startDate
            // 
            this.LoaddateTimePicker_startDate.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LoaddateTimePicker_startDate.Location = new System.Drawing.Point(53, 133);
            this.LoaddateTimePicker_startDate.Name = "LoaddateTimePicker_startDate";
            this.LoaddateTimePicker_startDate.Size = new System.Drawing.Size(252, 22);
            this.LoaddateTimePicker_startDate.TabIndex = 13;
            this.LoaddateTimePicker_startDate.Value = new System.DateTime(2023, 6, 15, 0, 0, 0, 0);
            // 
            // StartDateLabel
            // 
            this.StartDateLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.StartDateLabel.AutoSize = true;
            this.StartDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StartDateLabel.Location = new System.Drawing.Point(49, 96);
            this.StartDateLabel.Name = "StartDateLabel";
            this.StartDateLabel.Size = new System.Drawing.Size(86, 20);
            this.StartDateLabel.TabIndex = 14;
            this.StartDateLabel.Text = "Start Date";
            // 
            // EndDateLabel
            // 
            this.EndDateLabel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.EndDateLabel.AutoSize = true;
            this.EndDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EndDateLabel.Location = new System.Drawing.Point(469, 96);
            this.EndDateLabel.Name = "EndDateLabel";
            this.EndDateLabel.Size = new System.Drawing.Size(79, 20);
            this.EndDateLabel.TabIndex = 15;
            this.EndDateLabel.Text = "End Date";
            // 
            // LoadButtonOpenFileDialog
            // 
            this.LoadButtonOpenFileDialog.FileName = "openFileDialog1";
            this.LoadButtonOpenFileDialog.Filter = "All Stock files| *.csv| Daily Stocks|*-Day.csv| Weekly Stocks|*-Week.csv|Monthly " +
    "Stocks|*-Month.csv";
            this.LoadButtonOpenFileDialog.InitialDirectory = "C:\\Users\\rachi\\Desktop\\Proj 2\\Proj 1\\Stock Data";
            this.LoadButtonOpenFileDialog.Multiselect = true;
            this.LoadButtonOpenFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.LoadButtonOpenFileDialog_FileOk);
            // 
            // FormEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 213);
            this.Controls.Add(this.EndDateLabel);
            this.Controls.Add(this.StartDateLabel);
            this.Controls.Add(this.LoaddateTimePicker_startDate);
            this.Controls.Add(this.LoaddateTimePicker_endDate);
            this.Controls.Add(this.button_Load);
            this.Controls.Add(this.MainLabel);
            this.Name = "FormEntry";
            this.Text = "Stock Analysis";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MainLabel;
        private System.Windows.Forms.Button button_Load;
        private System.Windows.Forms.DateTimePicker LoaddateTimePicker_endDate;
        private System.Windows.Forms.DateTimePicker LoaddateTimePicker_startDate;
        private System.Windows.Forms.Label StartDateLabel;
        private System.Windows.Forms.Label EndDateLabel;
        private System.Windows.Forms.OpenFileDialog LoadButtonOpenFileDialog;
    }
}