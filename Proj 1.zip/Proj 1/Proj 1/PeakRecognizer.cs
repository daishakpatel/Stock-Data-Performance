﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj_1
{
    internal class PeakRecognizer : Recognizer
    {
        public PeakRecognizer() : base("Peak", 3)
        {

        }

        protected override Boolean recognizePattern(List<smartCandleStick> scsl)
        {
            return (scsl[1].high > scsl[0].high && scsl[1].high > scsl[2].high);
        }
    }
}
